
#ifndef STRIGI_EXPORT_H
#define STRIGI_EXPORT_H

#ifdef STRIGI_STATIC_DEFINE
#  define STRIGI_EXPORT
#  define STRIGI_NO_EXPORT
#else
#  ifndef STRIGI_EXPORT
#    ifdef streams_EXPORTS
        /* We are building this library */
#      define STRIGI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define STRIGI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef STRIGI_NO_EXPORT
#    define STRIGI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef STRIGI_DEPRECATED
#  define STRIGI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef STRIGI_DEPRECATED_EXPORT
#  define STRIGI_DEPRECATED_EXPORT STRIGI_EXPORT STRIGI_DEPRECATED
#endif

#ifndef STRIGI_DEPRECATED_NO_EXPORT
#  define STRIGI_DEPRECATED_NO_EXPORT STRIGI_NO_EXPORT STRIGI_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef STRIGI_NO_DEPRECATED
#    define STRIGI_NO_DEPRECATED
#  endif
#endif

#endif /* STRIGI_EXPORT_H */
