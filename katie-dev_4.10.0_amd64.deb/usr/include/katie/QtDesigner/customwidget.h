#include <QtDesigner/../QtUiTools/customwidget.h>
